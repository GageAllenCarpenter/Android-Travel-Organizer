package edu.wgu.capstone.view.dialog;

/**
 * Base interface for all dialog listeners.
 */
public interface DialogListener {}
